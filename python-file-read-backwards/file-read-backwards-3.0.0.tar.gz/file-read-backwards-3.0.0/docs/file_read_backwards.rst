file\_read\_backwards package
=============================

Submodules
----------

file\_read\_backwards.buffer\_work\_space module
------------------------------------------------

.. automodule:: file_read_backwards.buffer_work_space
   :members:
   :undoc-members:
   :show-inheritance:

file\_read\_backwards.file\_read\_backwards module
--------------------------------------------------

.. automodule:: file_read_backwards.file_read_backwards
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: file_read_backwards
   :members:
   :undoc-members:
   :show-inheritance:
